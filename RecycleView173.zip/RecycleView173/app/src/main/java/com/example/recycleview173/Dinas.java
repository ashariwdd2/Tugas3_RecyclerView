package com.example.recycleview173;

public class Dinas {
    private String namadinas;
    private String desdinas;
    private int logo;

    public String getNamadinas() {
        return namadinas;
    }

    public void setNamadinas(String namadinas) {
        this.namadinas = namadinas;
    }

    public String getDesdinas() {
        return desdinas;
    }

    public void setDesdinas(String desdinas) {
        this.desdinas = desdinas;
    }

    public int getLogo() {
        return logo;
    }

    public void setLogo(int logo) {
        this.logo = logo;
    }
}
